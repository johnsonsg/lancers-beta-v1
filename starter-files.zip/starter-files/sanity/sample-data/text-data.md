chimi hendirx
* Chimichurri
* Squash
* Mushrooms
* Roasted Garlic

Here Comes Truffle
* Roasted Garlic
* Mushrooms
* Truffle

Dough Exotic
* Steak
* sardine oil
* Chimichurri

The Friendship Ender
* Pineapple
* Ham
* Hot Peppers

Piggy Smalls
* Pulled Pork
* Pepperoni
* Bacon
* Sausage
* Onions

White after Labour Day
* Peppers
* Olives
* Basil
* Tomatoes

Nacho Average Pizza
* Hot Peppers
* Avocado Crema
* Shredded Lettuce
* Ground Beef

The Bee Sting
* Soppressata
* Honey

The Pear Necessities
* Pear
* Sweet Potato
* Spinach
* Honey

Pepperphony
* Vegan Pepperoni
* Vegan Cheese
* Peppers
* Basil

Holy Shiitake
* Roasted Garlic
* Mushrooms
* Onions
* Truffle

Cluck Norris
* Chicken
* Onions
* Hot Peppers


## people


Slick is the proprietor, he inherited the business from his late grandfather. Refers to himself as the Pablo Escobar of pizza. He grows his own tomatoes and won’t let anyone else near them...a little odd but we like him.

Roscoe is the leftover manager. Loves Puperoni. Currently on a diet.

After spending a summer in the New Mexico desert, August became passionate about circular foods. First it was waffles, now it is pizza.

Some say Waldo is searching for the freshest ingredients, but in reality pizza isn't a passion, it's a paycheck. Deep down, Waldo is still trying to find himself.

Oak grows his own basil at home and brings it in. While he loves pizza, it pays the bills while he works on his hot sauce startup. Went his whole life calling the crust a "Pizza Border".

Louise runs an Etsy shop that sells hand-painted elephant ceramics customized based on your astrology sign. Judges you for ordering extra sauce.

Enoch played guitar in a ska band but was forced out due to creative differences. Claim to fame is that a picture of Enoch comes up first when you Google 'people enjoying Italian street foods'.

Piper went to Italy once. Will tell you how much better the pizza is 'over there'. She has no college debt.

Fia qualified for Canada's 2018 rhythmic gymnastics olympic but left the sport to focus full-time on pizza, where she's developing a new kind of pizza toss (a very fast one where you do a flip)



